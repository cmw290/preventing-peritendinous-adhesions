clear
close all
S=dir('RawXY/');
S=S(4:end);
N={S.name};

for ratfile=1:length(N)
Filename=N{ratfile}(1:end-4);
% Filename='D1_1_w8'; % for analyzing a specific file
A=readmatrix(['RawXY/' Filename '.txt']);

start=[]; %contains indices where a step begins (contact with paw and ground)
A=A(3:end,:); %remove column headers
AB=[A(:,4)-A(:,2),A(:,5)-A(:,3)]; %generate vectors from point a to b (hip to knee)
BC=[A(:,6)-A(:,4),A(:,7)-A(:,5)]; %generate vectors from point a to b (knee to hip)
hor=[-1 0]; %reference horizontal unit vector
hor=repmat(hor,length(AB(:,1)),1);

LegAngle=[A(:,1),180-acosd(dot(AB,hor,2)./(sqrt(AB(:,1).^2+AB(:,2).^2)))];
LegAngle((AB(:,2)>0),2)=-LegAngle((AB(:,2)>0),2);
FootAngle=[A(:,1),180-acosd(dot(BC,hor,2)./(sqrt(BC(:,1).^2+BC(:,2).^2)))];
FootAngle((BC(:,2)>0),2)=360-FootAngle((BC(:,2)>0),2);
Angle=[A(:,1),FootAngle(:,2)-LegAngle(:,2)-90]; %Ankle angle

% plotting angle vs position
% hold on
% plot(Angle(:,1),Angle(:,2),'LineWidth',2); ylabel('Angle (deg)'); xlabel('time (s)') %angle vs time
% yyaxis right
% scatter(A(:,1),A(:,7)); ylabel('foot height (cm)'); %y position of foot vs time
% title('angles and positions')

derivy=diff(A(:,7))./diff(A(:,1)); %dy/dx for y position
derivx=diff(A(:,6))./diff(A(:,1)); %dy/dx for x position
new=0; %skip first step so we can start in the middle of movement.
% In analysis, start tracking before the previous mid-swing or insert 
% artificial local max on tracked foot before step

for k = 2:length(A(:,7))-1 %find where a step begins by checking when
    % the foot stops moving (derivatives drop to low/zero)

    if all(abs([derivx(k) derivy(k)])<4) && new && A(k,7)<1
        start = [start; k+1]; %add new starting index for this run
        new=0;
    end
    if any(islocalmax(A(k-1:k+1,7))) && A(k,7)>1.7
        new=1; %set true once foot is high and crosses a maximum
        % (midswing of a step). Algorithm will now detect new step when foot hits ground
    end
    
end

mins=zeros((length(start)-1),1); %initialize vectors for storing info
maxes=mins;


for k = 1:(length(start)-1)

    s = start(k); %gait cycle starts when foot first contacts ground (start of stance phase)
    f = start(k+1); %gait cycle ends when foot contacts ground again (end of swing phase)
    Sample = [(Angle(s:f,1)-Angle(s,1))./(Angle(f,1)-Angle(s,1)), Angle(s:f,2)]; 
    %generate matrix for angle over the course of one step, normalized by progress through step
    dy=derivy(s:f);
    dx=derivx(s:f);
    y=A(s:f,7);
    t=A(s:f,1);
    [~,ymax]=max(y);
    lift=find(dy>10,1); %time when foot first lifts off the ground,
    %used to determine significant index for other parameters
    
    if(any(isnan(Sample(lift:end,2))))
        maxes(k)=NaN; %knee of some rats became hidden behind skin fold 
        % during some swing cycles, max dorsiflexion angle is not determined when this happens
    else
        maxes(k)=max(Sample(:,2)); %minimum angle in gait cycle
    end

    if(any(isnan(Sample(1:lift,2))) || isnan(A(end))) %knee of some rats 
        % became hidden behind skin fold during parts of some gait cycles, 
        % max plantarflexion is not determined when this happens
        mins(k)=NaN;
    else
        mins(k)=min(Sample(:,2)); %maximum plantarflexion in gait cycle
    end

    % figure
    % hold on
    % title('normalized steps'); xlabel('step progress'); ylabel('Angle (deg)')
    % plot(Sample(:,1),Sample(:,2),'LineWidth',2);
    % lg=legend(1:j);

    writematrix(Sample,['StepAnglePlots/normalized/' Filename '_step' num2str(k) '_winter.txt']) %save angle vs norm gait matrix

    
end


% figure
% xd=(A(1:end-1,1)+A(2:end,1))/2; %recentered x values for plotting derivatives
% %scatter(A(:,1),A(:,7));
% 
% hold on
% plot(Angle(:,1),Angle(:,2),'LineWidth',2); ylabel('Angle (deg)')
% %scatter(A(:,1),A(:,6)); 
% 
% yyaxis right
% plot(xd,derivx,'LineWidth',2);
% plot(xd,derivy,'LineWidth',2); ylabel('derivative (cm/s)'); xlabel('time (s)')
% title('angles and derivatives')

titles=["Time (s)", "Angle (deg)"];
Angle=[titles;Angle];

out=[mins,maxes];
writematrix(out,['outputs/' Filename '_outputs_winter.txt']);
writematrix(Angle,['StepAnglePlots/raw/' Filename '_out_winter.txt']);
end

clear

header = {'min', 'max', 'ROM'};
S=dir('outputs/');
S=S(4:end); %3 to end for winter, 4 to end for normal
N={S.name};
rats=cellfun(@(s) s(1:2), N, 'uni',0);
[~,~,ic]=unique(rats);

preoutput=zeros(24,3);
d5output=preoutput;
w8output=preoutput;


for j=1:length(N)
    sub=readmatrix(['outputs/'  N{j}]);
    if contains(N{j},'pre')
        preoutput(ic(j),:) =[mean(sub(:,1:2),1,'omitnan') mean(sub(:,2)-sub(:,1),'omitnan')];
    elseif contains(N{j},'w8')
        w8output(ic(j),:) = [mean(sub(:,1:2),1,'omitnan') mean(sub(:,2)-sub(:,1),'omitnan')];
    elseif contains(N{j},'d5')
        d5output(ic(j),:) = [mean(sub(:,1:2),1,'omitnan') mean(sub(:,2)-sub(:,1),'omitnan')];
    end
end
preoutput=[header; num2cell(preoutput)];
d5output=[header; num2cell(d5output)];
w8output=[header; num2cell(w8output)];