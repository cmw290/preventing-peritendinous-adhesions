clear
close all

%subject of analysis
sub=readmatrix('RawData/SampleData.txt');
%empty vectors to store variables
slope = zeros(4,1); %slope of regime 1
dmax = slope; %maximum in derivative
dmins=slope; %minimum in derivative
slope2=slope; %slope of regime 2
r2start=slope; %start of regime 2
r2crosshead=slope;
r2load=slope;
work=slope;
worki=slope; %index to begin work of flexion calculation
start=[find(islocalmin(sub(:,3)));length(sub)];
finish=[find(islocalmax(sub(:,3)));length(sub)];

for run=1:4
    [~,i1]=min(abs(sub(start(run):finish(run+1),1)-0.5)); %start at load = 0.5 N
    [~,i2]=min(abs(sub(start(run):finish(run+1),1)-4.5)); %end at load = 4.5 N
    slope(run)=(sub(i2,1)-sub(i1,1))/(sub(i2,3)-sub(i1,3));
    
    %plot load vs crosshead (distance pulled)
    figure
    plot(sub(start(run):finish(run+1),3),sub(start(run):finish(run+1),1),'LineWidth',2);
    ylabel('Load (N)')
    %plot derivative
    deriv=diff(sub(start(run):finish(run+1),1))./diff(sub(start(run):finish(run+1),3)); %dy/dx
    xd=(sub(start(run):finish(run+1)-1,3)+sub(start(run)+1:finish(run+1),3))/2; %average center x values for plotting
    hold on
    yyaxis right
    plot(xd(5:end-4),deriv(5:end-4),'Color','r','LineWidth',2); title('run = ',run)
    dmax(run)=max(deriv(5:end-4)); %find max in derivative
    [dmins(run),mini]=min(deriv(5:end-4));mini=mini+4; %find min in derivative and adjust to true index
    slope2(run)=mean(deriv(mini-3:mini+3)); %estimate slope in the second regime by derivative
    
    probe=[1 2 3]; %will be used to index for a mean
    val=slope(run); %will be the mean defined by indices in "probe"

    while abs(val-slope(run))<slope(run)*.45 %loop until this mean is 45% lower than intial slope
        val=mean(deriv(probe+17)); %add 17 to avoid early regime
        probe=probe+1; %move probe along the plot
    end
    r2start(run)=probe(2)+17; %take center index from probe as start of regime2
    
    r2crosshead(run)=sub(start(run)+r2start(run)-1,3); %crosshead at start of r2
    r2load(run)=sub(start(run)+r2start(run)-1,1); %load at start of r2
    [~,worki(run)]=min(abs(sub(start(run):finish(run+1),3)-(r2crosshead(run)+2.5))); %find index 2.5mm after r2 starts
    work(run)=trapz(sub(start(run)+r2start(run)-1:start(run)+worki(run)-1,3),... %use trapezoids to integrate for work
        sub(start(run)+r2start(run)-1:start(run)+worki(run)-1,1));
    ylabel('dy/dx')
    xlabel('Crosshead (mm)')
    yyaxis left
    scatter(r2crosshead(run),r2load(run))

end

out=[r2load,slope,work];
meanout=mean(out,1);